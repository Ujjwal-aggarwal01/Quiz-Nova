const questions = [
{
question: "Which language is used to structure web pages?",
options: ["HTML", "Python", "Java", "C++"],
answer: "HTML"
},
{
question: "Which language is mainly used for styling web pages?",
options: ["CSS", "C", "Java", "Python"],
answer: "CSS"
},
{
question: "Which language is used to make web pages interactive?",
options: ["JavaScript", "HTML", "SQL", "C"],
answer: "JavaScript"
},
{
question: "Which tag is used to create a hyperlink in HTML?",
options: ["<a>", "<h1>", "<p>", "<img>"],
answer: "<a>"
},
{
question: "Which database language is used to retrieve data?",
options: ["SQL", "Python", "Java", "HTML"],
answer: "SQL"
}
];

let currentQuestion = 0;
let score = 0;

const question = document.getElementById("question");
const optionButtons = document.getElementsByClassName("option");

loadQuestion();

function loadQuestion(){

question.innerHTML = questions[currentQuestion].question;

for(let i=0;i<4;i++){
optionButtons[i].textContent = questions[currentQuestion].options[i];
}

}

function checkAnswer(index){

if(questions[currentQuestion].options[index]===questions[currentQuestion].answer){
score++;
alert("Correct Answer!");
}
else{
alert("Wrong Answer!");
}

}

function nextQuestion(){

currentQuestion++;

// Update Progress Bar
document.getElementById("progress-bar").style.width =
((currentQuestion) / questions.length) * 100 + "%";

if(currentQuestion < questions.length){

loadQuestion();

}
else{

localStorage.setItem("score", score);

window.location.href = "result.html";

}

}

if(document.getElementById("finalScore")){

if(document.getElementById("finalScore")){
    document.getElementById("finalScore").innerHTML =
    localStorage.getItem("score") + "/5";
}

}
let timeLeft = 30;

const timer = setInterval(function(){

    if(document.getElementById("timer")){
        document.getElementById("timer").innerHTML = timeLeft;
    }

    timeLeft--;

    if(timeLeft < 0){
        clearInterval(timer);
        alert("Time is up!");
        nextQuestion();
    }

},1000);
